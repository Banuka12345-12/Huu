import React from 'react';
import { Message, Role } from '../types';
import LoadingDots from './LoadingDots';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === Role.USER;

  // Function to format text with basic line breaks and bolding
  // Since we can't use external markdown libraries easily, we'll do basic processing
  const formatText = (text: string) => {
    return text.split('\n').map((line, i) => (
      <React.Fragment key={i}>
        {line}
        <br />
      </React.Fragment>
    ));
  };

  return (
    <div className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} mb-6`}>
      <div
        className={`
          relative max-w-[85%] md:max-w-[70%] px-5 py-3.5 rounded-2xl text-sm md:text-base leading-relaxed shadow-md
          ${isUser 
            ? 'bg-blue-600 text-white rounded-br-none' 
            : 'bg-gray-800 text-gray-100 rounded-bl-none border border-gray-700'
          }
          ${message.isError ? 'bg-red-900/50 border-red-800 text-red-200' : ''}
        `}
      >
        {message.isStreaming && !message.text ? (
          <LoadingDots />
        ) : (
          <div className="whitespace-pre-wrap break-words font-normal">
            {message.text}
          </div>
        )}
        
        <div className={`text-[10px] mt-1 opacity-60 ${isUser ? 'text-blue-100' : 'text-gray-400'} text-right`}>
          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;