import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

// Ensure we use the environment variable as per strict guidelines
const API_KEY = process.env.API_KEY || '';

export class GeminiService {
  private chat: Chat | null = null;
  private ai: GoogleGenAI;

  constructor() {
    if (!API_KEY) {
      console.error("API_KEY is missing from environment variables.");
    }
    this.ai = new GoogleGenAI({ apiKey: API_KEY });
  }

  public startChat() {
    this.chat = this.ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: 'You are a helpful, intelligent, and friendly AI assistant. You answer questions concisely and accurately.',
      },
    });
  }

  public async *sendMessageStream(message: string): AsyncGenerator<string, void, unknown> {
    if (!this.chat) {
      this.startChat();
    }

    if (!this.chat) {
      throw new Error("Failed to initialize chat session.");
    }

    try {
      const result = await this.chat.sendMessageStream({ message });
      
      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        if (c.text) {
          yield c.text;
        }
      }
    } catch (error) {
      console.error("Error sending message to Gemini:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();